#include "headers.h" 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	printf("*******Problem1 Testing*******\n");
	testProblem1();

	printf("\n\n\n*******Problem2 Testing*******\n");
	testProblem2();
	
	printf("\n\n\n*******Problem3 Testing*******\n");
	testProblem3();
	
	printf("\n\n\n*******Problem4 Testing*******\n");
	testProblem4();
	
	printf("\n\n\n*******Problem5 Testing*******\n");
	testProblem5();
	
	printf("\n\n\n*******Problem6 Testing*******\n");
	testProblem6();
	
	printf("\n\n");
	system("pause");
	return 0;
}
