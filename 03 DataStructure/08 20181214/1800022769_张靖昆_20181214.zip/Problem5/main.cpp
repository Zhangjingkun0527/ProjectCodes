#include "definitions.h"

int main() {
    //打印顺序检索情况
    print_search_times_for_sequential_search();
    //打印二分检索情况
    print_search_times_for_binary_search();

    return 0;
}