package com.moodlevideo.server.util;

public class MoodleVideoResponseModel {
	/**
	 * 服务器状态
	 */
	private String server_status;
	/**
	 * 服务器错误状态描述
	 */
	private String server_error;
	/**
	 * 
	 */
	private String data;
}
