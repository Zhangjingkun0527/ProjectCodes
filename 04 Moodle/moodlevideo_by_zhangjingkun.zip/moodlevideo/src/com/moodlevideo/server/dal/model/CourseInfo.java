package com.moodlevideo.server.dal.model;

public class CourseInfo
{
  private Integer id;
  private String name;
  private String school;
  private String reference;
  
  public Integer getId()
  {
    return this.id;
  }
  
  public void setId(Integer id)
  {
    this.id = id;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    this.name = (name == null ? null : name.trim());
  }
  
  public String getSchool()
  {
    return this.school;
  }
  
  public void setSchool(String school)
  {
    this.school = (school == null ? null : school.trim());
  }
  
  public String getReference()
  {
    return this.reference;
  }
  
  public void setReference(String reference)
  {
    this.reference = (reference == null ? null : reference.trim());
  }
}
